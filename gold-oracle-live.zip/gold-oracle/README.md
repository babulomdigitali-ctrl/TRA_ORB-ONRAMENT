# ✦ Gold Oracle — Deployment Guide

## What this is
A mobile-first Gold trading intelligence web app with:
- Real Gold + DXY price data (2024–2026)
- Oracle scoring system (COT, Lunar, DXY, Fear/Greed, Sentiment, Numerology, Mercury)
- Tarot pre-trade psychological mirror
- Trade journal with persistent storage
- Subconscious Mind AI (powered by Claude)
- Pattern recognition of YOUR personal gut accuracy

---

## Deploy to Vercel (free, 5 minutes)

### Step 1 — Install Node.js
Download from https://nodejs.org (LTS version)

### Step 2 — Install Vercel CLI
```bash
npm install -g vercel
```

### Step 3 — Install dependencies
```bash
cd gold-oracle
npm install
```

### Step 4 — Test locally first
```bash
npm run dev
```
Open http://localhost:5173 — app should run perfectly.

### Step 5 — Deploy
```bash
vercel
```
Follow the prompts:
- Set up and deploy? **Y**
- Which scope? (your account)
- Link to existing project? **N**
- Project name: **gold-oracle**
- Directory: **./**
- Build command: **npm run build**
- Output directory: **dist**

Vercel gives you a live URL like: `https://gold-oracle-xyz.vercel.app`

### Step 6 — Share
Send that URL to anyone. It works on mobile like a native app.

---

## Add to iPhone home screen (PWA)
1. Open the URL in Safari
2. Tap the Share button
3. "Add to Home Screen"
4. The app icon appears — opens fullscreen like a native app

---

## Notes
- Trade journal saves in browser localStorage (persists across sessions on same device)
- Subconscious Mind uses Claude API — works without any additional keys
- To update data, edit `/src/data.js` — add new monthly Gold/DXY prices

---

## Project structure
```
gold-oracle/
├── index.html              # Entry point
├── package.json            # Dependencies
├── vite.config.js          # Build config
└── src/
    ├── main.jsx            # React root
    ├── App.jsx             # Navigation + state
    ├── theme.js            # Colors + fonts
    ├── data.js             # Real market data + Oracle formula
    ├── subconscious.js     # Claude AI integration
    └── screens/
        ├── OracleScreen.jsx    # Oracle score + price chart
        ├── TarotScreen.jsx     # Pre-trade card reading
        ├── JournalScreen.jsx   # Trade logging
        ├── MindScreen.jsx      # Subconscious AI chat
        └── PatternsScreen.jsx  # Gut accuracy analytics
```
