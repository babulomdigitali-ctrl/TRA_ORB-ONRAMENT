// api/chart.js — Intraday chart bars for Gold
// Returns 5-minute OHLC bars for today's session

async function fetchBars(ticker, interval = "5m", range = "1d") {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?interval=${interval}&range=${range}`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "application/json",
    },
  });
  if (!res.ok) throw new Error(`${res.status}`);
  const data = await res.json();
  const result = data?.chart?.result?.[0];
  if (!result) throw new Error("No chart data");

  const quotes = result.indicators?.quote?.[0];
  const timestamps = result.timestamp || [];

  return timestamps.map((t, i) => ({
    time:   t * 1000,
    open:   quotes.open?.[i],
    high:   quotes.high?.[i],
    low:    quotes.low?.[i],
    close:  quotes.close?.[i],
    volume: quotes.volume?.[i],
  })).filter(b => b.close != null);
}

export default async function handler(req, res) {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");

  const { interval = "5m", range = "1d" } = req.query;

  try {
    const bars = await fetchBars("GC=F", interval, range);
    res.status(200).json({ bars, fetchedAt: Date.now() });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
