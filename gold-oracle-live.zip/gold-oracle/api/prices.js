// api/prices.js — Vercel Serverless Function
// Fetches XAU/USD (Gold) and DXY from Yahoo Finance every call.
// No API key required. Runs server-side so CORS is not an issue.
// Deployed at: yourapp.vercel.app/api/prices

const TICKERS = {
  gold: "GC=F",   // Gold Futures — closest to XAU/USD spot
  dxy:  "DX-Y.NYB", // US Dollar Index
  gld:  "GLD",    // GLD ETF (backup if futures unavailable)
};

async function fetchYahoo(ticker) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${ticker}?interval=5m&range=1d`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      "Accept": "application/json",
    },
  });
  if (!res.ok) throw new Error(`Yahoo fetch failed for ${ticker}: ${res.status}`);
  const data = await res.json();
  const result = data?.chart?.result?.[0];
  if (!result) throw new Error(`No data for ${ticker}`);

  const meta = result.meta;
  const quotes = result.indicators?.quote?.[0];
  const timestamps = result.timestamp || [];

  // Build OHLCV bars
  const bars = timestamps.map((t, i) => ({
    time: t * 1000,
    open:  quotes.open?.[i],
    high:  quotes.high?.[i],
    low:   quotes.low?.[i],
    close: quotes.close?.[i],
    volume: quotes.volume?.[i],
  })).filter(b => b.close != null);

  return {
    ticker,
    price:      meta.regularMarketPrice,
    prevClose:  meta.previousClose || meta.chartPreviousClose,
    open:       meta.regularMarketOpen,
    dayHigh:    meta.regularMarketDayHigh,
    dayLow:     meta.regularMarketDayLow,
    change:     meta.regularMarketPrice - (meta.previousClose || meta.chartPreviousClose),
    changePct:  ((meta.regularMarketPrice - (meta.previousClose || meta.chartPreviousClose)) / (meta.previousClose || meta.chartPreviousClose)) * 100,
    currency:   meta.currency,
    marketState: meta.marketState, // REGULAR | PRE | POST | CLOSED
    timestamp:  meta.regularMarketTime * 1000,
    bars: bars.slice(-100), // last 100 five-minute bars
  };
}

export default async function handler(req, res) {
  // Allow CORS from your own app
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET");
  res.setHeader("Cache-Control", "s-maxage=60, stale-while-revalidate=300");

  try {
    // Fetch Gold and DXY in parallel
    const [gold, dxy] = await Promise.allSettled([
      fetchYahoo(TICKERS.gold),
      fetchYahoo(TICKERS.dxy),
    ]);

    const goldData = gold.status === "fulfilled" ? gold.value : null;
    const dxyData  = dxy.status  === "fulfilled" ? dxy.value  : null;

    // If Gold futures failed, try GLD ETF and scale to spot price
    let goldFinal = goldData;
    if (!goldFinal) {
      try {
        const gld = await fetchYahoo(TICKERS.gld);
        goldFinal = { ...gld, price: gld.price * 9.85, ticker: "GLD_SCALED" };
      } catch(e) {
        goldFinal = null;
      }
    }

    if (!goldFinal) {
      return res.status(503).json({ error: "Gold price unavailable", fallback: true });
    }

    res.status(200).json({
      gold: goldFinal,
      dxy:  dxyData,
      fetchedAt: Date.now(),
      nextRefresh: Date.now() + 5 * 60 * 1000,
    });

  } catch (err) {
    res.status(500).json({ error: err.message, fallback: true });
  }
}
