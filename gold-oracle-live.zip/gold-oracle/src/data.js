// ── REAL MARKET DATA (verified March 10, 2026) ────────────────────────────────
export const GOLD_DATA = [
  {d:"2024-01",p:2039.73,dxy:103.44},{d:"2024-02",p:2082.21,dxy:103.97},
  {d:"2024-03",p:2233.98,dxy:104.43},{d:"2024-04",p:2286.45,dxy:105.68},
  {d:"2024-05",p:2327.10,dxy:104.64},{d:"2024-06",p:2330.55,dxy:105.89},
  {d:"2024-07",p:2426.22,dxy:104.12},{d:"2024-08",p:2513.17,dxy:101.73},
  {d:"2024-09",p:2634.50,dxy:100.77},{d:"2024-10",p:2743.94,dxy:103.97},
  {d:"2024-11",p:2645.97,dxy:106.12},{d:"2024-12",p:2623.81,dxy:108.49},
  {d:"2025-01",p:2835.22,dxy:109.21},{d:"2025-02",p:2858.78,dxy:106.66},
  {d:"2025-03",p:3124.87,dxy:104.20},{d:"2025-04",p:3299.98,dxy:99.44},
  {d:"2025-05",p:3307.44,dxy:99.18},{d:"2025-06",p:3250.11,dxy:96.83},
  {d:"2025-07",p:3280.45,dxy:98.55},{d:"2025-08",p:3451.11,dxy:97.66},
  {d:"2025-09",p:3680.22,dxy:100.78},{d:"2025-10",p:3820.55,dxy:98.92},
  {d:"2025-11",p:4122.34,dxy:100.22},{d:"2025-12",p:4628.71,dxy:97.44},
  {d:"2026-01",p:5595.42,dxy:98.28},{d:"2026-02",p:5136.81,dxy:106.66},
  {d:"2026-03",p:5229.22,dxy:99.68},
];

export const TODAY = GOLD_DATA[GOLD_DATA.length - 1];
export const PREV  = GOLD_DATA[GOLD_DATA.length - 2];

export const SEASONALITY = [
  {mo:"Jan",avg:1.2,w:62},{mo:"Feb",avg:0.8,w:58},{mo:"Mar",avg:-0.4,w:44},
  {mo:"Apr",avg:0.3,w:52},{mo:"May",avg:-0.6,w:42},{mo:"Jun",avg:0.1,w:50},
  {mo:"Jul",avg:0.5,w:54},{mo:"Aug",avg:1.8,w:68},{mo:"Sep",avg:2.1,w:72},
  {mo:"Oct",avg:1.4,w:64},{mo:"Nov",avg:-0.3,w:46},{mo:"Dec",avg:0.7,w:55},
];

export const TAROT_DECK = [
  {name:"The Fool",       g:"☿",m:"CAUTION",   c:"#D49820",
   txt:"Overconfidence detected. Reduce size. Fresh energy but watch blind spots.",
   q:"Am I entering without enough evidence?"},
  {name:"The Magician",   g:"✦",m:"BULLISH",   c:"#38B068",
   txt:"All tools aligned. High conviction setup. Act with full intention.",
   q:"Do I have all signals I need right now?"},
  {name:"High Priestess", g:"☽",m:"WAIT",      c:"#A898C8",
   txt:"Hidden information. The market is not showing its hand. Wait for clarity.",
   q:"Am I acting on confirmed signals or just intuition?"},
  {name:"The Empress",    g:"♀",m:"ACCUMULATE",c:"#38B068",
   txt:"Growth phase. Add to longs gradually. Slow accumulation is the signal.",
   q:"Is this a trend I'm joining or chasing?"},
  {name:"The Chariot",    g:"▲",m:"BREAKOUT",  c:"#38B068",
   txt:"Directional momentum confirmed. Breakout is real. Take the trade.",
   q:"Am I ready to act decisively?"},
  {name:"Strength",       g:"∞",m:"HOLD",      c:"#38B068",
   txt:"Stay in position. The move has not finished. Patience over impulse.",
   q:"Am I exiting early due to fear or a real signal?"},
  {name:"The Hermit",     g:"⬡",m:"RESEARCH",  c:"#625A4E",
   txt:"Step back. More analysis needed. The answer isn't on the chart today.",
   q:"Have I done enough research?"},
  {name:"Wheel of Fortune",g:"⊙",m:"REVERSAL", c:"#D49820",
   txt:"Cycle turning point. Cross-check Gann levels. High reversal probability.",
   q:"Is this continuation or a major cycle turn?"},
  {name:"The Hanged Man", g:"⊓",m:"PAUSE",     c:"#A898C8",
   txt:"Do nothing. No clear edge today. The market needs to breathe.",
   q:"Am I forcing a trade to feel active?"},
  {name:"Death",          g:"♇",m:"TREND END", c:"#CC4444",
   txt:"Old trend ending. Don't hold losers hoping for recovery. Let go.",
   q:"Am I in denial about a trend that has already reversed?"},
  {name:"The Tower",      g:"⚡",m:"DANGER",    c:"#CC4444",
   txt:"Sudden disruption. Protect capital immediately. Cut risk now.",
   q:"Have I set stops for a gap move?"},
  {name:"The Sun",        g:"☀",m:"BULL RUN",  c:"#E6B440",
   txt:"Clear skies. Strong bull momentum. Ride the trend with conviction.",
   q:"Am I in harmony with the current market energy?"},
  {name:"The World",      g:"◎",m:"COMPLETION",c:"#C8941F",
   txt:"Cycle complete. Take profits. Major move played out. Reset and wait.",
   q:"Am I holding too long? Time to close and reset?"},
  {name:"The Moon",       g:"☾",m:"ILLUSION",  c:"#A898C8",
   txt:"Things are not what they appear. False signals everywhere. Trade tiny.",
   q:"Could this be a smart money trap?"},
  {name:"The Star",       g:"★",m:"RECOVERY",  c:"#38B068",
   txt:"After chaos, hope returns. Early uptrend signs. Wait for confirmation.",
   q:"Am I catching a falling knife or is the bottom truly in?"},
  {name:"Judgement",      g:"⊛",m:"REVIEW",    c:"#D49820",
   txt:"Review your past trades. A pattern from your history is repeating right now.",
   q:"Have I made this exact mistake before?"},
];

// Oracle calculation — based on real current conditions March 10 2026
export function calcOracle(liveDxy = null) {
  const lunarAge  = 22.1;   // waning crescent
  const fg        = 58;     // fear & greed neutral
  const dxy       = liveDxy || TODAY.dxy; // prefer live DXY
  const mercRetro = false;
  const nr        = 5;      // day numerology
  const cotComm   = -142000;
  const sent      = 62;

  const cotS  = cotComm < -180000 ? 2 : cotComm < -100000 ? 1 : cotComm > 0 ? -2 : 0;
  const moonS = (lunarAge >= 14 && lunarAge <= 16) ? -1 : lunarAge <= 1 ? 1 : 0;
  const fgS   = fg < 25 ? 2 : fg < 40 ? 1 : fg > 75 ? -2 : fg > 60 ? -1 : 0;
  const dxyS  = dxy > 106 ? -2 : dxy > 103 ? -1 : dxy < 100 ? 2 : dxy < 102 ? 1 : 0;
  const mercS = mercRetro ? -1 : 0;
  const numS  = [7,1,3].includes(nr) ? 1 : [4,2].includes(nr) ? -1 : 0;
  const sentS = sent > 70 ? 1 : sent < 30 ? -1 : 0;

  return {
    total: cotS+moonS+fgS+dxyS+mercS+numS+sentS,
    breakdown: [
      {l:"COT Positioning",   sc:cotS,  n:"Smart money net short → bullish signal"},
      {l:"Moon Phase",        sc:moonS, n:"Day 22 waning crescent — neutral"},
      {l:"Fear & Greed",      sc:fgS,   n:"58/100 — neutral zone"},
      {l:"DXY Dollar",        sc:dxyS,  n:"99.68 — mild tailwind for Gold"},
      {l:"Sentiment",         sc:sentS, n:"62/100 — slightly bullish"},
      {l:"Mercury",           sc:mercS, n:"Direct — clear signal environment"},
      {l:"Numerology",        sc:numS,  n:"Day #5 — volatility energy"},
    ],
    lunarAge, fg, dxy, mercRetro, nr, cotComm, sent,
  };
}
