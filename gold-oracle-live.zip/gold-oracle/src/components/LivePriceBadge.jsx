// src/components/LivePriceBadge.jsx
import { C } from "../theme.js";

export default function LivePriceBadge({ price, change, changePct, dxy, dxyChange,
  marketState, lastUpdated, countdown, loading, error, isLive, onRefresh }) {

  const up = change >= 0;
  const mktColor = marketState === "REGULAR" ? C.bull
    : marketState === "PRE" || marketState === "POST" ? C.neutral : C.muted;
  const mktLabel = marketState === "REGULAR" ? "● LIVE"
    : marketState === "PRE"  ? "◐ PRE-MKT"
    : marketState === "POST" ? "◑ AFTER-HRS"
    : "○ CLOSED";

  const fmt = (n) => n != null ? `$${Number(n).toLocaleString(undefined, {minimumFractionDigits:2,maximumFractionDigits:2})}` : "—";
  const fmtPct = (n) => n != null ? `${n>=0?"+":""}${n.toFixed(2)}%` : "";

  return (
    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start" }}>
      {/* Left: Gold price */}
      <div>
        <div style={{ display:"flex", alignItems:"center", gap:6 }}>
          <div style={{ fontSize:8, color:C.goldD, letterSpacing:4, textTransform:"uppercase" }}>
            Gold Oracle
          </div>
          {isLive && (
            <div style={{ fontSize:7, color:mktColor, letterSpacing:1,
              padding:"1px 5px", borderRadius:8,
              background:`${mktColor}18`, border:`1px solid ${mktColor}44` }}>
              {mktLabel}
            </div>
          )}
        </div>
        <div style={{ fontSize:20, color:C.gold, letterSpacing:2, lineHeight:1.2,
          textShadow:`0 0 24px ${C.goldD}` }}>
          ✦ {loading && !price ? "Loading..." : fmt(price)}
        </div>
        {change != null && (
          <div style={{ fontSize:10, color:up ? C.bull : C.bear, marginTop:1 }}>
            {up ? "▲" : "▼"} {fmt(Math.abs(change))} ({fmtPct(changePct)}) today
          </div>
        )}
      </div>

      {/* Right: DXY + refresh */}
      <div style={{ textAlign:"right" }}>
        <div style={{ fontSize:11, color:dxyChange <= 0 ? C.bull : C.bear, fontWeight:"bold" }}>
          DXY {dxy?.toFixed(2) || "—"}
        </div>
        <div style={{ fontSize:9, color:dxyChange <= 0 ? C.bull : C.bear }}>
          {dxyChange != null ? `${dxyChange >= 0 ? "▲" : "▼"} ${Math.abs(dxyChange).toFixed(2)}` : ""}
          {" "}{dxy < 102 ? "↑ Gold tailwind" : dxy > 104 ? "↓ Gold headwind" : ""}
        </div>
        {/* Refresh control */}
        <button onClick={onRefresh} title="Refresh now" style={{
          marginTop:4, background:"transparent", border:`1px solid ${C.border}`,
          borderRadius:6, padding:"2px 7px", color:C.muted, cursor:"pointer",
          fontSize:9, fontFamily:"inherit", display:"flex", alignItems:"center",
          gap:4, marginLeft:"auto" }}>
          <span style={{ display:"inline-block",
            animation: loading ? "spin 1s linear infinite" : "none" }}>↻</span>
          {loading ? "fetching…" : isLive ? `${countdown}s` : error ? "retry" : `${countdown}s`}
        </button>
        {!isLive && !loading && (
          <div style={{ fontSize:8, color:C.bear, marginTop:2 }}>using cached data</div>
        )}
      </div>

      <style>{`@keyframes spin { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }`}</style>
    </div>
  );
}
