// src/components/IntradayChart.jsx
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { C } from "../theme.js";

export default function IntradayChart({ bars, currentPrice, loading }) {
  if (loading || !bars?.length) {
    return (
      <div style={{ height:160, display:"flex", alignItems:"center", justifyContent:"center",
        color:C.muted, fontSize:11 }}>
        {loading ? "Loading intraday data…" : "No intraday bars available (market may be closed)"}
      </div>
    );
  }

  const chartData = bars.map(b => ({
    time: new Date(b.time).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}),
    price: b.close,
    high: b.high,
    low: b.low,
  }));

  const open = bars[0]?.open;
  const prices = bars.map(b => b.close);
  const min = Math.min(...prices) * 0.9995;
  const max = Math.max(...prices) * 1.0005;
  const isUp = (currentPrice || bars[bars.length-1]?.close) >= open;

  return (
    <ResponsiveContainer width="100%" height={160}>
      <AreaChart data={chartData}>
        <defs>
          <linearGradient id="iG" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%"  stopColor={isUp ? C.bull : C.bear} stopOpacity={0.3}/>
            <stop offset="95%" stopColor={isUp ? C.bull : C.bear} stopOpacity={0}/>
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
        <XAxis dataKey="time" tick={{fill:C.muted,fontSize:7}} interval="preserveStartEnd"/>
        <YAxis domain={[min, max]} tick={{fill:C.muted,fontSize:8}}
          tickFormatter={v => `$${Math.round(v).toLocaleString()}`}/>
        <Tooltip
          contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,fontSize:10}}
          formatter={v => [`$${Number(v).toLocaleString(undefined,{minimumFractionDigits:2})}`, "Gold"]}/>
        {open && <ReferenceLine y={open} stroke={C.muted} strokeDasharray="4 4" opacity={0.5}
          label={{value:"Open",fill:C.muted,fontSize:8,position:"insideTopRight"}}/>}
        <Area type="monotone" dataKey="price"
          stroke={isUp ? C.bull : C.bear} fill="url(#iG)" strokeWidth={2} dot={false}/>
      </AreaChart>
    </ResponsiveContainer>
  );
}
