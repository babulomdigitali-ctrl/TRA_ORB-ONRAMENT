import { useState, useEffect, useCallback } from "react";
import { C, font } from "./theme.js";
import { calcOracle } from "./data.js";
import { useLivePrice } from "./hooks/useLivePrice.js";
import LivePriceBadge from "./components/LivePriceBadge.jsx";
import OracleScreen   from "./screens/OracleScreen.jsx";
import TarotScreen    from "./screens/TarotScreen.jsx";
import JournalScreen  from "./screens/JournalScreen.jsx";
import MindScreen     from "./screens/MindScreen.jsx";
import PatternsScreen from "./screens/PatternsScreen.jsx";

const NAV = [
  { id:"oracle",   icon:"🔮", label:"Oracle"   },
  { id:"tarot",    icon:"🃏", label:"Tarot"    },
  { id:"journal",  icon:"📓", label:"Journal"  },
  { id:"mind",     icon:"🧠", label:"Mind"     },
  { id:"patterns", icon:"📊", label:"Patterns" },
];

export default function App() {
  const [screen, setScreen]         = useState("oracle");
  const [trades, setTrades]         = useState([]);
  const [tarot, setTarot]           = useState(null);
  const [notif, setNotif]           = useState(null);
  const [pendingMindMsg, setPendingMindMsg] = useState(null);

  const live   = useLivePrice();
  const oracle = calcOracle(live.dxy);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("gold_oracle_v2_trades");
      if (saved) setTrades(JSON.parse(saved));
    } catch(e) {}
  }, []);

  useEffect(() => {
    try { localStorage.setItem("gold_oracle_v2_trades", JSON.stringify(trades)); } catch(e) {}
  }, [trades]);

  const showNotif = useCallback((msg) => {
    setNotif(msg);
    setTimeout(() => setNotif(null), 3500);
  }, []);

  useEffect(() => {
    if (Math.abs(oracle.total) >= 3) {
      setTimeout(() => showNotif(
        oracle.total >= 3 ? "🟢 Strong Bull Signal!" : "🔴 Strong Bear Signal!"
      ), 1400);
    }
  }, [oracle.total]);

  useEffect(() => {
    if (live.isLive && Math.abs(live.goldChangePct) > 1.5) {
      showNotif(`⚡ Gold ${live.goldChangePct > 0 ? "up" : "down"} ${Math.abs(live.goldChangePct).toFixed(1)}% today`);
    }
  }, [live.isLive]);

  const goToMind = (msg) => { setPendingMindMsg(msg); setScreen("mind"); };

  return (
    <div style={{ background:C.bg, minHeight:"100vh", color:C.text,
      fontFamily:font, maxWidth:480, margin:"0 auto", paddingBottom:72 }}>

      {notif && (
        <div style={{ position:"fixed", top:14, left:"50%", transform:"translateX(-50%)",
          background:C.gold, color:C.bg, padding:"8px 20px", borderRadius:20,
          fontSize:12, fontWeight:"bold", zIndex:1000, letterSpacing:1, whiteSpace:"nowrap",
          boxShadow:`0 4px 24px ${C.goldD}BB`, animation:"slideIn 0.3s ease" }}>
          {notif}
        </div>
      )}

      <div style={{ padding:"14px 16px 10px", borderBottom:`1px solid ${C.border}`,
        background:`linear-gradient(180deg,#0C0C1E 0%,${C.bg} 100%)`,
        position:"sticky", top:0, zIndex:100 }}>
        <LivePriceBadge {...live} onRefresh={live.refresh} />
        <div style={{ marginTop:10, display:"flex", gap:8, alignItems:"center" }}>
          <div style={{ flex:1, height:4, background:C.deep, borderRadius:2, overflow:"hidden" }}>
            <div style={{ height:"100%", borderRadius:2,
              width:`${((oracle.total+7)/14)*100}%`,
              background:`linear-gradient(90deg,${C.bear} 0%,${C.neutral} 50%,${C.bull} 100%)`,
              transition:"width 1s ease" }}/>
          </div>
          <div style={{ fontSize:11, fontWeight:"bold", minWidth:72, textAlign:"right",
            color:oracle.total>=2?C.bull:oracle.total<=-2?C.bear:C.neutral }}>
            {oracle.total>0?"+":""}{oracle.total} {oracle.total>=2?"BULL":oracle.total<=-2?"BEAR":"NEUT"}
          </div>
        </div>
      </div>

      <div>
        {screen==="oracle"   && <OracleScreen  live={live} oracle={oracle} onGoTarot={()=>setScreen("tarot")}/>}
        {screen==="tarot"    && <TarotScreen   tarot={tarot} setTarot={setTarot}
                                  onLogTrade={()=>setScreen("journal")} onAskMind={goToMind}/>}
        {screen==="journal"  && <JournalScreen trades={trades} setTrades={setTrades} showNotif={showNotif}/>}
        {screen==="mind"     && <MindScreen    trades={trades} tarot={tarot}
                                  initialMsg={pendingMindMsg} onLoad={()=>setPendingMindMsg(null)}
                                  liveGold={live.gold} liveDxy={live.dxy}/>}
        {screen==="patterns" && <PatternsScreen trades={trades} onGoJournal={()=>setScreen("journal")}/>}
      </div>

      <div style={{ position:"fixed", bottom:0, left:"50%", transform:"translateX(-50%)",
        width:"100%", maxWidth:480, zIndex:100 }}>
        <div style={{ background:C.card, borderTop:`1px solid ${C.border}`, display:"flex" }}>
          {NAV.map(n => (
            <button key={n.id} onClick={()=>setScreen(n.id)} style={{
              flex:1, padding:"10px 4px 12px", border:"none",
              background:"transparent", cursor:"pointer", fontFamily:font,
              display:"flex", flexDirection:"column", alignItems:"center", gap:3,
              borderTop:screen===n.id?`2px solid ${C.gold}`:"2px solid transparent",
              transition:"all 0.15s" }}>
              <span style={{fontSize:18}}>{n.icon}</span>
              <span style={{fontSize:8,letterSpacing:1,textTransform:"uppercase",
                color:screen===n.id?C.gold:C.muted}}>{n.label}</span>
            </button>
          ))}
        </div>
      </div>

      <style>{`
        *{-webkit-tap-highlight-color:transparent;box-sizing:border-box;}
        ::-webkit-scrollbar{width:3px;}
        ::-webkit-scrollbar-track{background:transparent;}
        ::-webkit-scrollbar-thumb{background:${C.border};border-radius:2px;}
        @keyframes slideIn{from{opacity:0;transform:translateX(-50%) translateY(-10px);}to{opacity:1;transform:translateX(-50%) translateY(0);}}
      `}</style>
    </div>
  );
}
