export async function askSubconscious(trades, tarotCard, oracleScore, userMessage) {
  const resolved = trades.filter(t => t.outcome);
  const wins = resolved.filter(t => t.outcome === "win");
  const gutAccuracy = resolved.length > 0
    ? Math.round(wins.length / resolved.length * 100)
    : null;

  const tradeContext = trades.length > 0
    ? trades.slice(-10).map(t =>
        `[${t.date}] Gut: "${t.gut}" | Direction: ${t.direction} | Outcome: ${t.outcome || "pending"} | Notes: "${t.notes}"`
      ).join("\n")
    : "No trades logged yet. Encourage the trader to start logging.";

  const systemPrompt = `You are the Subconscious Mind — a wise AI embedded in a Gold trading oracle app.

You are NOT a financial advisor. You never give specific buy/sell recommendations.
You speak in a calm, precise, slightly mystical but honest tone — like a mentor who has seen everything.

Your role:
1. Reflect the trader's own patterns back to them with clarity
2. Ask one sharp, uncomfortable psychological question when needed
3. Warn them when you see a pattern that has caused losses before
4. Celebrate genuine discipline — not just wins
5. Be concise: 2-4 sentences unless they ask something deep

Current market context (March 10, 2026):
- Gold XAU/USD: $5,229 (down from ATH $5,595 on Jan 29, 2026)
- DXY: 99.68 (mild tailwind for Gold)
- Oracle Score: ${oracleScore >= 2 ? "BULLISH" : oracleScore <= -2 ? "BEARISH" : "NEUTRAL"} (${oracleScore > 0 ? "+" : ""}${oracleScore}/14)
- Tarot drawn: ${tarotCard ? `${tarotCard.name} — ${tarotCard.m} — "${tarotCard.txt}"` : "No card drawn yet"}
- March seasonality: historically weak (-0.4% avg, 44% win rate)

Trader's recent journal (most recent first):
${tradeContext}

${gutAccuracy !== null
  ? `Gut accuracy: ${gutAccuracy}% across ${resolved.length} resolved trades (${wins.length} wins)`
  : "No resolved trades yet — not enough data for accuracy calculation."}

Speak directly to the trader as "you". Start with the most important insight first.`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1000,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }],
    }),
  });

  if (!response.ok) {
    throw new Error(`API error: ${response.status}`);
  }

  const data = await response.json();
  return data.content?.[0]?.text || "The subconscious is quiet. Try asking again.";
}
