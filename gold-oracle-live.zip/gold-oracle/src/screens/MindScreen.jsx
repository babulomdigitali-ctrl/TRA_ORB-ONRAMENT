import { useState, useRef, useEffect, useMemo } from "react";
import { C } from "../theme.js";
import { askSubconscious } from "../subconscious.js";
import { calcOracle } from "../data.js";

const QUICK = [
  "What pattern do you see in my trades?",
  "Am I ready to trade today?",
  "What is my biggest psychological weakness?",
  "Review my last 5 trades honestly",
  "When am I most likely to make mistakes?",
];

export default function MindScreen({ trades, tarot }) {
  const [history, setHistory] = useState([]);
  const [msg, setMsg]         = useState("");
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);
  const oracle = useMemo(() => calcOracle(), []);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior:"smooth" }); }, [history]);

  const send = async (text) => {
    const m = text || msg;
    if (!m.trim() || loading) return;
    setHistory(h => [...h, { role:"user", content:m }]);
    setMsg("");
    setLoading(true);
    try {
      const reply = await askSubconscious(trades, tarot, oracle.total, m);
      setHistory(h => [...h, { role:"ai", content:reply }]);
    } catch(e) {
      setHistory(h => [...h, { role:"ai", content:`The subconscious connection was interrupted. Please try again. (${e.message})` }]);
    }
    setLoading(false);
  };

  const resolved = trades.filter(t => t.outcome);
  const wins = resolved.filter(t => t.outcome === "win");
  const accuracy = resolved.length > 0 ? Math.round(wins.length / resolved.length * 100) : null;

  return (
    <div style={{ padding:"16px 14px 0", display:"flex", flexDirection:"column", gap:12 }}>

      {/* Header card */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
        <div style={{ fontSize:9, color:C.moon, letterSpacing:3, marginBottom:10, textTransform:"uppercase" }}>
          The Subconscious Mind
        </div>
        <p style={{ fontSize:11, color:C.muted, lineHeight:1.8, margin:0 }}>
          This AI has read your full trade journal and knows your patterns.
          It speaks your history back to you — not as a financial advisor,
          but as a mirror of your own psychology.
          {accuracy !== null && (
            <span style={{ color:C.goldL }}> Your current gut accuracy: <strong>{accuracy}%</strong>.</span>
          )}
        </p>
      </div>

      {/* Chat */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, overflow:"hidden" }}>
        {/* Messages */}
        <div style={{ height:340, overflowY:"auto", padding:"14px 14px 8px" }}>
          {history.length === 0 && (
            <div style={{ textAlign:"center", padding:"32px 0", color:C.muted, fontSize:12, lineHeight:2 }}>
              <div style={{ fontSize:32, marginBottom:8 }}>🧠</div>
              The subconscious is listening.<br/>
              <span style={{ color:C.goldL }}>Ask it what it sees in your patterns.</span>
            </div>
          )}
          {history.map((h, i) => (
            <div key={i} style={{ marginBottom:14,
              display:"flex", flexDirection:"column",
              alignItems: h.role==="user" ? "flex-end" : "flex-start" }}>
              <div style={{
                maxWidth:"87%", padding:"9px 13px", borderRadius:12,
                background: h.role==="user" ? `${C.goldD}99` : C.deep,
                border:`1px solid ${h.role==="user" ? C.goldD : C.border}`,
                fontSize:12, lineHeight:1.75,
                color: h.role==="user" ? C.goldL : C.text }}>
                {h.content}
              </div>
              <div style={{ fontSize:8, color:C.muted, marginTop:3 }}>
                {h.role==="user" ? "You" : "🧠 Subconscious"}
              </div>
            </div>
          ))}
          {loading && (
            <div style={{ display:"flex", alignItems:"flex-start", marginBottom:12 }}>
              <div style={{ background:C.deep, border:`1px solid ${C.border}`,
                borderRadius:12, padding:"9px 13px", fontSize:12, color:C.muted }}>
                Reading the patterns<span style={{ animation:"dots 1.2s infinite" }}>...</span>
              </div>
            </div>
          )}
          <div ref={endRef}/>
        </div>

        {/* Quick prompts */}
        <div style={{ padding:"6px 10px", borderTop:`1px solid ${C.border}`,
          display:"flex", gap:5, flexWrap:"wrap" }}>
          {QUICK.map((q, i) => (
            <button key={i} onClick={() => send(q)} style={{
              fontSize:9, padding:"4px 9px", borderRadius:20,
              background:C.deep, border:`1px solid ${C.border}`,
              color:C.muted, cursor:"pointer", fontFamily:"inherit",
              transition:"all 0.15s" }}>
              {q}
            </button>
          ))}
        </div>

        {/* Input */}
        <div style={{ padding:"8px 10px", borderTop:`1px solid ${C.border}`,
          display:"flex", gap:8 }}>
          <input
            value={msg}
            onChange={e => setMsg(e.target.value)}
            onKeyDown={e => e.key==="Enter" && !e.shiftKey && send()}
            placeholder="Ask your subconscious mind..."
            style={{ flex:1, background:C.deep, border:`1px solid ${C.border}`,
              borderRadius:8, padding:"8px 10px", color:C.text, fontSize:12,
              fontFamily:"inherit", outline:"none" }}/>
          <button onClick={() => send()} disabled={loading} style={{
            background:loading?C.muted:C.gold, border:"none", borderRadius:8,
            padding:"8px 14px", color:C.bg, cursor:loading?"not-allowed":"pointer",
            fontSize:14, fontWeight:"bold", transition:"all 0.15s" }}>
            ↑
          </button>
        </div>
      </div>

      {/* Stats the AI knows */}
      {trades.length > 0 && (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
          <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>
            What the Mind Knows About You
          </div>
          <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:8 }}>
            {[
              {l:"Trades Logged",   v:trades.length,                                c:C.text},
              {l:"Resolved",        v:resolved.length,                              c:C.text},
              {l:"Gut Accuracy",    v:accuracy!=null?`${accuracy}%`:"—",           c:accuracy>60?C.bull:accuracy>40?C.neutral:C.bear},
              {l:"Wins",            v:wins.length,                                  c:C.bull},
              {l:"Losses",          v:resolved.filter(t=>t.outcome==="loss").length,c:C.bear},
              {l:"Pending",         v:trades.filter(t=>!t.outcome).length,          c:C.muted},
            ].map((x,i) => (
              <div key={i} style={{ background:C.deep, borderRadius:9, padding:"9px",
                border:`1px solid ${C.border}`, textAlign:"center" }}>
                <div style={{ fontSize:7, color:C.muted, textTransform:"uppercase", letterSpacing:1, marginBottom:3 }}>{x.l}</div>
                <div style={{ fontSize:18, color:x.c, fontWeight:"bold" }}>{x.v}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <style>{`
        @keyframes dots { 0%,20%{content:"."} 40%{content:".."} 60%,100%{content:"..."} }
      `}</style>
    </div>
  );
}
