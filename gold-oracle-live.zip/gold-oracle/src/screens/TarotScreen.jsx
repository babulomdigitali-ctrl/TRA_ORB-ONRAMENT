import { useState } from "react";
import { C } from "../theme.js";
import { TAROT_DECK } from "../data.js";

export default function TarotScreen({ tarot, setTarot, onLogTrade, onAskMind }) {
  const [show, setShow] = useState(!!tarot);

  const draw = () => {
    setShow(false);
    setTimeout(() => {
      setTarot(TAROT_DECK[Math.floor(Math.random() * TAROT_DECK.length)]);
      setShow(true);
    }, 300);
  };

  return (
    <div style={{ padding:"16px 14px", display:"flex", flexDirection:"column", gap:12 }}>
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
        <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>
          Pre-Trade Psychological Mirror
        </div>
        <p style={{ fontSize:11, color:C.muted, lineHeight:1.8, marginBottom:16 }}>
          Before any trade — draw a card. Not for prediction. For honest self-reflection.
          Ask yourself: <em style={{ color:C.goldL }}>"What internal energy am I bringing right now?"</em>
        </p>
        <button onClick={draw} style={{
          background:`linear-gradient(135deg,${C.goldD},${C.gold})`,
          color:C.bg, border:"none", borderRadius:10, padding:"12px",
          fontSize:13, fontFamily:"inherit", cursor:"pointer",
          letterSpacing:2, fontWeight:"bold", width:"100%", marginBottom:16 }}>
          ✦ DRAW A CARD ✦
        </button>

        {tarot ? (
          <div style={{
            opacity: show ? 1 : 0,
            transform: show ? "translateY(0) scale(1)" : "translateY(12px) scale(0.97)",
            transition: "all 0.5s cubic-bezier(0.34,1.56,0.64,1)",
            background:C.deep, borderRadius:12, padding:20,
            border:`1px solid ${tarot.c}44`, textAlign:"center" }}>
            <div style={{ fontSize:38, marginBottom:6 }}>{tarot.g}</div>
            <div style={{ fontSize:18, color:tarot.c, marginBottom:4, letterSpacing:1 }}>{tarot.name}</div>
            <div style={{ display:"inline-block", padding:"2px 12px", borderRadius:20, marginBottom:14,
              background:`${tarot.c}22`, border:`1px solid ${tarot.c}55`,
              fontSize:9, color:tarot.c, letterSpacing:3 }}>{tarot.m}</div>
            <p style={{ fontSize:12, color:C.text, lineHeight:1.8, marginBottom:14 }}>{tarot.txt}</p>
            <div style={{ borderTop:`1px solid ${C.border}`, paddingTop:12 }}>
              <div style={{ fontSize:8, color:C.gold, letterSpacing:2, marginBottom:6 }}>ASK YOURSELF</div>
              <div style={{ fontSize:12, color:C.goldL, fontStyle:"italic" }}>"{tarot.q}"</div>
            </div>
          </div>
        ) : (
          <div style={{ textAlign:"center", padding:"28px 0", color:C.muted, fontSize:12 }}>
            Draw a card to receive your reading
          </div>
        )}
      </div>

      {tarot && (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
          <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>
            After Your Reading
          </div>
          <p style={{ fontSize:11, color:C.muted, lineHeight:1.7, marginBottom:12 }}>
            Now choose your next step. Log the trade with your gut feeling, or ask
            the Subconscious Mind if this card matches your historical patterns.
          </p>
          <div style={{ display:"flex", gap:8 }}>
            <button onClick={onLogTrade} style={{
              flex:1, background:C.deep, border:`1px solid ${C.border}`, color:C.goldL,
              borderRadius:9, padding:"11px", cursor:"pointer", fontFamily:"inherit", fontSize:11 }}>
              📓 Log This Trade
            </button>
            <button onClick={() => onAskMind(`I just drew the ${tarot.name} card (${tarot.m}). What does this reveal about my current psychological state given my trade history?`)}
              style={{ flex:1, background:C.deep, border:`1px solid ${C.border}`, color:C.moon,
                borderRadius:9, padding:"11px", cursor:"pointer", fontFamily:"inherit", fontSize:11 }}>
              🧠 Ask the Mind
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
