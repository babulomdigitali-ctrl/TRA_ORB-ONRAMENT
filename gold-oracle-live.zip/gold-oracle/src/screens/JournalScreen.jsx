import { useState } from "react";
import { C } from "../theme.js";

const empty = () => ({
  date: new Date().toISOString().split("T")[0],
  gut: "", direction: "long", outcome: "", notes: "",
});

export default function JournalScreen({ trades, setTrades, showNotif }) {
  const [form, setForm] = useState(empty());

  const add = () => {
    if (!form.gut.trim()) { showNotif("Write your gut feeling first"); return; }
    setTrades(t => [{ ...form, id: Date.now() }, ...t]);
    setForm(empty());
    showNotif("Trade logged ✓");
  };

  const updateOutcome = (id, outcome) => {
    setTrades(t => t.map(tr => tr.id === id ? { ...tr, outcome } : tr));
    showNotif(`Marked as ${outcome} ✓`);
  };

  const inp = (style={}) => ({
    width:"100%", background:C.deep, border:`1px solid ${C.border}`,
    borderRadius:8, padding:"8px 10px", color:C.text, fontSize:12,
    fontFamily:"inherit", outline:"none", boxSizing:"border-box", ...style
  });

  return (
    <div style={{ padding:"16px 14px", display:"flex", flexDirection:"column", gap:12 }}>

      {/* New trade form */}
      <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
        <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:14, textTransform:"uppercase" }}>
          Log New Trade
        </div>
        <div style={{ display:"flex", flexDirection:"column", gap:10 }}>
          <div>
            <div style={{ fontSize:9, color:C.muted, marginBottom:4, textTransform:"uppercase", letterSpacing:1 }}>Date</div>
            <input type="date" value={form.date}
              onChange={e => setForm(f => ({ ...f, date:e.target.value }))}
              style={inp()} />
          </div>

          <div>
            <div style={{ fontSize:9, color:C.muted, marginBottom:4, textTransform:"uppercase", letterSpacing:1 }}>Gut Feeling</div>
            <textarea value={form.gut}
              onChange={e => setForm(f => ({ ...f, gut:e.target.value }))}
              placeholder="I feel Gold will... because I notice..."
              style={inp({ resize:"none", minHeight:70, lineHeight:1.6 })} />
          </div>

          <div>
            <div style={{ fontSize:9, color:C.muted, marginBottom:6, textTransform:"uppercase", letterSpacing:1 }}>Direction</div>
            <div style={{ display:"flex", gap:7 }}>
              {["long","short","neutral"].map(d => (
                <button key={d} onClick={() => setForm(f => ({ ...f, direction:d }))} style={{
                  flex:1, padding:"8px 4px", borderRadius:8, cursor:"pointer",
                  fontFamily:"inherit", fontSize:11, textTransform:"uppercase", letterSpacing:1,
                  background: form.direction===d ? (d==="long"?C.bull:d==="short"?C.bear:C.neutral) : C.deep,
                  color: form.direction===d ? C.bg : C.muted,
                  border:`1px solid ${form.direction===d?"transparent":C.border}`,
                  transition:"all 0.15s" }}>
                  {d==="long"?"▲ Long":d==="short"?"▼ Short":"— Neutral"}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div style={{ fontSize:9, color:C.muted, marginBottom:6, textTransform:"uppercase", letterSpacing:1 }}>Outcome (fill now or later)</div>
            <div style={{ display:"flex", gap:7 }}>
              {["","win","loss","breakeven"].map(o => (
                <button key={o} onClick={() => setForm(f => ({ ...f, outcome:o }))} style={{
                  flex:1, padding:"7px 4px", borderRadius:8, cursor:"pointer",
                  fontFamily:"inherit", fontSize:10,
                  background: form.outcome===o && o!=="" ? (o==="win"?C.bull:o==="loss"?C.bear:C.neutral) : C.deep,
                  color: form.outcome===o && o!=="" ? C.bg : C.muted,
                  border:`1px solid ${form.outcome===o&&o!==""?"transparent":C.border}`,
                  transition:"all 0.15s" }}>
                  {o===""?"Pending":o.charAt(0).toUpperCase()+o.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div style={{ fontSize:9, color:C.muted, marginBottom:4, textTransform:"uppercase", letterSpacing:1 }}>Notes</div>
            <input value={form.notes}
              onChange={e => setForm(f => ({ ...f, notes:e.target.value }))}
              placeholder="Oracle score? Tarot card? What signals did you see?"
              style={inp()} />
          </div>

          <button onClick={add} style={{
            background:`linear-gradient(135deg,${C.goldD},${C.gold})`,
            color:C.bg, border:"none", borderRadius:10, padding:"12px",
            fontSize:13, fontFamily:"inherit", cursor:"pointer",
            letterSpacing:1, fontWeight:"bold", marginTop:4 }}>
            ✦ LOG TRADE
          </button>
        </div>
      </div>

      {/* Trade history */}
      {trades.length > 0 ? (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18 }}>
          <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>
            Trade History ({trades.length})
          </div>
          <div style={{ display:"flex", flexDirection:"column", gap:8, maxHeight:400, overflowY:"auto" }}>
            {trades.map(t => (
              <div key={t.id} style={{ background:C.deep, borderRadius:9, padding:"10px 12px",
                border:`1px solid ${t.outcome==="win"?C.bull+"44":t.outcome==="loss"?C.bear+"44":C.border}` }}>
                <div style={{ display:"flex", justifyContent:"space-between", marginBottom:5 }}>
                  <span style={{ fontSize:10, color:C.muted }}>{t.date}</span>
                  <span style={{ fontSize:9, padding:"1px 8px", borderRadius:10,
                    background:t.direction==="long"?`${C.bull}22`:t.direction==="short"?`${C.bear}22`:`${C.neutral}22`,
                    color:t.direction==="long"?C.bull:t.direction==="short"?C.bear:C.neutral }}>
                    {t.direction==="long"?"▲":t.direction==="short"?"▼":"—"} {t.direction}
                  </span>
                </div>
                <div style={{ fontSize:11, color:C.text, marginBottom:6, lineHeight:1.5 }}>{t.gut}</div>
                {t.notes && <div style={{ fontSize:10, color:C.muted, marginBottom:6, fontStyle:"italic" }}>{t.notes}</div>}
                {!t.outcome ? (
                  <div style={{ display:"flex", gap:5, alignItems:"center" }}>
                    <span style={{ fontSize:9, color:C.muted }}>Outcome: </span>
                    {["win","loss","breakeven"].map(o => (
                      <button key={o} onClick={() => updateOutcome(t.id, o)} style={{
                        fontSize:9, padding:"3px 9px", borderRadius:8, cursor:"pointer",
                        background:C.card, border:`1px solid ${C.border}`, color:C.muted,
                        fontFamily:"inherit" }}>
                        {o}
                      </button>
                    ))}
                  </div>
                ) : (
                  <span style={{ fontSize:10, padding:"2px 10px", borderRadius:10,
                    background:t.outcome==="win"?`${C.bull}22`:t.outcome==="loss"?`${C.bear}22`:`${C.neutral}22`,
                    color:t.outcome==="win"?C.bull:t.outcome==="loss"?C.bear:C.neutral }}>
                    {t.outcome.toUpperCase()}
                  </span>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:28,
          textAlign:"center", color:C.muted, fontSize:12, lineHeight:2 }}>
          No trades logged yet.<br/>
          <span style={{ color:C.goldL }}>Every great trader starts with their first entry.</span>
        </div>
      )}
    </div>
  );
}
