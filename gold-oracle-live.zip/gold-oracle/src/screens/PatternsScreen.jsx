import { useMemo } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from "recharts";
import { C, mono } from "../theme.js";
import { SEASONALITY } from "../data.js";

export default function PatternsScreen({ trades, onGoJournal }) {
  const stats = useMemo(() => {
    const resolved = trades.filter(t => t.outcome);
    if (resolved.length < 3) return null;

    const wins   = resolved.filter(t => t.outcome === "win");
    const losses = resolved.filter(t => t.outcome === "loss");
    const accuracy = Math.round(wins.length / resolved.length * 100);

    const longR = resolved.filter(t => t.direction === "long");
    const shortR = resolved.filter(t => t.direction === "short");
    const longAcc  = longR.length  > 0 ? Math.round(longR.filter(t=>t.outcome==="win").length/longR.length*100)   : null;
    const shortAcc = shortR.length > 0 ? Math.round(shortR.filter(t=>t.outcome==="win").length/shortR.length*100) : null;

    let streak = 0;
    for (let i = 0; i < resolved.length; i++) {
      if (resolved[i].outcome === resolved[0].outcome) streak++;
      else break;
    }

    return { accuracy, total:resolved.length, wins:wins.length, losses:losses.length,
      longAcc, shortAcc, streak:{ count:streak, type:resolved[0]?.outcome } };
  }, [trades]);

  const card = (children, sx={}) => (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18, ...sx }}>
      {children}
    </div>
  );
  const lbl = t => (
    <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>{t}</div>
  );

  if (!stats) return (
    <div style={{ padding:"16px 14px" }}>
      {card(
        <div style={{ textAlign:"center", padding:"30px 0", color:C.muted, fontSize:12, lineHeight:2 }}>
          <div style={{ fontSize:36, marginBottom:10 }}>📊</div>
          Pattern recognition needs at least<br/>
          <strong style={{ color:C.goldL }}>3 resolved trades</strong> to activate.<br/>
          <div style={{ fontSize:11, marginTop:8, color:C.muted }}>
            You have {trades.filter(t=>t.outcome).length} resolved / {trades.length} logged
          </div>
          <button onClick={onGoJournal} style={{
            marginTop:14, background:C.goldD, border:"none", borderRadius:8,
            padding:"9px 20px", color:C.goldL, cursor:"pointer",
            fontFamily:"inherit", fontSize:11 }}>
            Open Journal →
          </button>
        </div>
      )}
    </div>
  );

  return (
    <div style={{ padding:"16px 14px", display:"flex", flexDirection:"column", gap:12 }}>

      {card(<>
        {lbl("Your Gut Accuracy")}
        <div style={{ textAlign:"center", padding:"8px 0 16px" }}>
          <div style={{ fontSize:52, fontWeight:"bold",
            color: stats.accuracy>60?C.bull:stats.accuracy>40?C.neutral:C.bear }}>
            {stats.accuracy}%
          </div>
          <div style={{ fontSize:11, color:C.muted, marginTop:4 }}>
            {stats.total} resolved trades · {stats.wins}W / {stats.losses}L
          </div>
          <div style={{ marginTop:12, height:8, background:C.deep, borderRadius:4, overflow:"hidden" }}>
            <div style={{ height:"100%", borderRadius:4, transition:"width 1s ease",
              width:`${stats.accuracy}%`,
              background:`linear-gradient(90deg, ${C.bear}, ${C.neutral} 50%, ${C.bull})` }}/>
          </div>
          <div style={{ display:"flex", justifyContent:"space-between", fontSize:8, color:C.muted, marginTop:3 }}>
            <span>0%</span><span>50%</span><span>100%</span>
          </div>
        </div>

        <div style={{ display:"grid", gridTemplateColumns:"repeat(3,1fr)", gap:8 }}>
          {[
            {l:"Long Accuracy",  v:stats.longAcc!=null?`${stats.longAcc}%`:"N/A",  c:C.bull},
            {l:"Short Accuracy", v:stats.shortAcc!=null?`${stats.shortAcc}%`:"N/A",c:C.bear},
            {l:"Current Streak", v:`${stats.streak.count}× ${stats.streak.type}`,  c:stats.streak.type==="win"?C.bull:C.bear},
          ].map((x,i) => (
            <div key={i} style={{ background:C.deep, borderRadius:9, padding:"10px",
              border:`1px solid ${C.border}`, textAlign:"center" }}>
              <div style={{ fontSize:7, color:C.muted, textTransform:"uppercase", letterSpacing:1, marginBottom:4 }}>{x.l}</div>
              <div style={{ fontSize:16, color:x.c, fontWeight:"bold" }}>{x.v}</div>
            </div>
          ))}
        </div>
      </>)}

      {card(<>
        {lbl("Your Formula")}
        <div style={{ background:C.deep, borderRadius:10, padding:14, fontFamily:mono,
          fontSize:10, color:C.muted, lineHeight:2.1, border:`1px solid ${C.borderGold}` }}>
          <div style={{ color:C.gold, marginBottom:4 }}>// SUBCONSCIOUS PATTERN ANALYSIS</div>
          <div><span style={{ color:C.gann }}>GUT_ACCURACY</span>   = <span style={{ color:stats.accuracy>60?C.bull:stats.accuracy>40?C.neutral:C.bear }}>{stats.accuracy}%</span></div>
          <div><span style={{ color:C.bull }}>LONG_BIAS</span>     = <span style={{ color:C.text }}>{stats.longAcc!=null?`${stats.longAcc}% win rate`:"Not enough data"}</span></div>
          <div><span style={{ color:C.bear }}>SHORT_BIAS</span>    = <span style={{ color:C.text }}>{stats.shortAcc!=null?`${stats.shortAcc}% win rate`:"Not enough data"}</span></div>
          <div><span style={{ color:C.moon }}>CURRENT_STREAK</span> = <span style={{ color:stats.streak.type==="win"?C.bull:C.bear }}>{stats.streak.count}× {stats.streak.type}</span></div>
          <div style={{ marginTop:6, color:C.gold }}>// NEXT MILESTONE</div>
          <div><span style={{ color:C.accent }}>TRADES_TO_20</span>  = {Math.max(0,20-stats.total)} remaining</div>
        </div>

        <p style={{ fontSize:11, color:C.muted, lineHeight:1.8, marginTop:12 }}>
          {stats.accuracy > 65
            ? "Your gut is strong. Real pattern recognition is developing. The Subconscious Mind recommends trusting signals that feel clear and acting on them. Doubt is your main enemy now."
            : stats.accuracy > 45
            ? "Your gut is developing. Average is fine at this stage. The Subconscious Mind sees you improving. Ask it where your wins and losses cluster — the pattern is already there."
            : "Your gut is in learning mode. Every loss is data, not failure. Ask the Subconscious Mind what it sees in your loss patterns specifically — this is where the growth is."}
        </p>
      </>)}

      {card(<>
        {lbl("Gold Seasonality Reference")}
        <ResponsiveContainer width="100%" height={130}>
          <BarChart data={SEASONALITY}>
            <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
            <XAxis dataKey="mo" tick={{fill:C.muted,fontSize:8}}/>
            <YAxis tick={{fill:C.muted,fontSize:8}}/>
            <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,fontSize:10}}
              formatter={v=>[`${v>0?"+":""}${v}%`,"Avg"]}/>
            <ReferenceLine y={0} stroke={C.border}/>
            <Bar dataKey="avg" radius={[3,3,0,0]} fill={C.gold}/>
          </BarChart>
        </ResponsiveContainer>
        <div style={{ fontSize:10, color:C.muted, marginTop:8, textAlign:"center" }}>
          Currently March — historically <span style={{ color:C.bear }}>-0.4% avg, 44% win rate</span>
        </div>
      </>)}
    </div>
  );
}
