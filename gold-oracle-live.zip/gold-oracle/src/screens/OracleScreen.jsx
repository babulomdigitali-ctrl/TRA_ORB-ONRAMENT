import { useEffect, useState } from "react";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { C } from "../theme.js";
import { GOLD_DATA } from "../data.js";
import IntradayChart from "../components/IntradayChart.jsx";

export default function OracleScreen({ live, oracle, onGoTarot }) {
  const [animated, setAnimated] = useState(false);
  useEffect(() => { setTimeout(() => setAnimated(true), 100); }, []);

  const card = (children, sx={}) => (
    <div style={{ background:C.card, border:`1px solid ${C.border}`, borderRadius:14, padding:18, ...sx }}>
      {children}
    </div>
  );
  const lbl = (t) => (
    <div style={{ fontSize:9, color:C.gold, letterSpacing:3, marginBottom:12, textTransform:"uppercase" }}>{t}</div>
  );

  return (
    <div style={{ padding:"16px 14px", display:"flex", flexDirection:"column", gap:12 }}>

      {/* Live intraday chart */}
      {card(<>
        {lbl(live.isLive
          ? `Today's Session — ${live.marketState === "REGULAR" ? "Live 5-min bars" : live.marketState}`
          : "Today — Cached Data")}
        <IntradayChart bars={live.bars} currentPrice={live.gold} loading={live.loading && !live.bars?.length}/>
        {live.isLive && live.goldDayHigh && (
          <div style={{ display:"flex", justifyContent:"space-between", marginTop:8 }}>
            {[
              {l:"Day High",  v:`$${live.goldDayHigh?.toLocaleString(undefined,{minimumFractionDigits:2})}`, c:C.bull},
              {l:"Current",   v:`$${live.gold?.toLocaleString(undefined,{minimumFractionDigits:2})}`,        c:C.gold},
              {l:"Day Low",   v:`$${live.goldDayLow?.toLocaleString(undefined,{minimumFractionDigits:2})}`,  c:C.bear},
            ].map((x,i) => (
              <div key={i} style={{ textAlign:"center" }}>
                <div style={{ fontSize:8, color:C.muted }}>{x.l}</div>
                <div style={{ fontSize:11, color:x.c, fontWeight:"bold" }}>{x.v}</div>
              </div>
            ))}
          </div>
        )}
      </>)}

      {/* Signal grid */}
      {card(<>
        {lbl("Oracle Signals — March 10, 2026")}
        <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:8 }}>
          {[
            {l:"DXY Dollar",   v:live.dxy?.toFixed(2) || "99.68",  s:live.dxy < 102 ? "Tailwind ↑ for Gold" : "Headwind ↓", c:live.dxy < 102 ? C.bull : C.bear},
            {l:"Seasonality",  v:"-0.4% avg",    s:"March — 44% win rate",   c:C.bear},
            {l:"Moon",         v:"🌘 Waning",     s:"Day 22 — low energy",    c:C.moon},
            {l:"Mercury",      v:"✓ Direct",      s:"Clear signals",           c:C.bull},
            {l:"Fear & Greed", v:"Neutral",       s:"58/100",                  c:C.neutral},
            {l:"Numerology",   v:"Day #5",        s:"Volatility energy",       c:C.neutral},
            {l:"Sentiment",    v:"Slightly Bull", s:"62/100",                  c:C.bull},
            {l:"COT Proxy",    v:"Smart$ Short",  s:"-142,000",                c:C.bull},
          ].map((x,i) => (
            <div key={i} style={{ background:C.deep, borderRadius:9, padding:"9px 11px",
              border:`1px solid ${C.border}`,
              opacity:animated?1:0, transform:animated?"translateY(0)":"translateY(8px)",
              transition:`all 0.35s ease ${i*0.05}s` }}>
              <div style={{ fontSize:8, color:C.muted, textTransform:"uppercase", letterSpacing:1, marginBottom:2 }}>{x.l}</div>
              <div style={{ fontSize:12, color:x.c, fontWeight:"bold" }}>{x.v}</div>
              <div style={{ fontSize:9, color:C.muted, marginTop:1 }}>{x.s}</div>
            </div>
          ))}
        </div>
      </>)}

      {/* Score breakdown */}
      {card(<>
        {lbl("Score Breakdown")}
        {oracle.breakdown.map((x,i) => (
          <div key={i} style={{ display:"flex", justifyContent:"space-between", alignItems:"center",
            marginBottom:8, padding:"5px 8px", background:C.deep, borderRadius:7 }}>
            <div>
              <div style={{ fontSize:11, color:C.text }}>{x.l}</div>
              <div style={{ fontSize:9, color:C.muted }}>{x.n}</div>
            </div>
            <div style={{ display:"flex", gap:3 }}>
              {[-2,-1,0,1,2].map(v => (
                <div key={v} style={{ width:16, height:16, borderRadius:3, fontSize:7,
                  display:"flex", alignItems:"center", justifyContent:"center",
                  background:x.sc===v?(v>0?C.bull:v<0?C.bear:C.neutral):"#0A0A16",
                  color:x.sc===v?C.bg:C.dim, fontWeight:"bold",
                  border:`1px solid ${x.sc===v?"transparent":C.border}` }}>
                  {v>0?"+":""}{v}
                </div>
              ))}
            </div>
          </div>
        ))}
        <div style={{ borderTop:`1px solid ${C.border}`, marginTop:10, paddingTop:10,
          display:"flex", justifyContent:"space-between" }}>
          <span style={{ fontSize:12, color:C.text }}>Total</span>
          <span style={{ fontSize:16, fontWeight:"bold",
            color:oracle.total>=2?C.bull:oracle.total<=-2?C.bear:C.neutral }}>
            {oracle.total>0?"+":""}{oracle.total} — {oracle.total>=2?"🟢 BULLISH":oracle.total<=-2?"🔴 BEARISH":"🟡 NEUTRAL"}
          </span>
        </div>
      </>)}

      {/* Historical chart */}
      {card(<>
        {lbl("Monthly History — Real Data 2024–2026")}
        <ResponsiveContainer width="100%" height={140}>
          <AreaChart data={GOLD_DATA.map(d=>({...d,label:d.d.slice(2)}))}>
            <defs>
              <linearGradient id="gG" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%"  stopColor={C.gold} stopOpacity={0.3}/>
                <stop offset="95%" stopColor={C.gold} stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" stroke={C.border}/>
            <XAxis dataKey="label" tick={{fill:C.muted,fontSize:7}} interval={4}/>
            <YAxis tick={{fill:C.muted,fontSize:8}} domain={["auto","auto"]}/>
            <Tooltip contentStyle={{background:C.card,border:`1px solid ${C.border}`,borderRadius:8,fontSize:10}}
              formatter={v=>[`$${Number(v).toLocaleString()}`,"Gold"]}/>
            <Area type="monotone" dataKey="p" stroke={C.gold} fill="url(#gG)" strokeWidth={2} dot={false}/>
          </AreaChart>
        </ResponsiveContainer>
      </>)}

      <button onClick={onGoTarot} style={{
        background:`linear-gradient(135deg,${C.goldD},${C.gold})`,
        color:C.bg, border:"none", borderRadius:12, padding:"13px", width:"100%",
        fontSize:13, fontFamily:"inherit", cursor:"pointer", letterSpacing:2, fontWeight:"bold",
        boxShadow:`0 4px 20px ${C.goldD}66` }}>
        ✦ DRAW TAROT BEFORE TRADING ✦
      </button>
    </div>
  );
}
