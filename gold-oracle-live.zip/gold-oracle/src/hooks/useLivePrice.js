// src/hooks/useLivePrice.js
// Polls the /api/prices serverless function every 5 minutes.
// Falls back to hardcoded data if the API is unavailable.
// Handles market open/closed states clearly.

import { useState, useEffect, useRef, useCallback } from "react";
import { TODAY } from "../data.js";

const REFRESH_MS = 5 * 60 * 1000; // 5 minutes

export function useLivePrice() {
  const [state, setState] = useState({
    gold:        TODAY.p,
    goldChange:  0,
    goldChangePct: 0,
    dxy:         TODAY.dxy,
    dxyChange:   0,
    bars:        [],        // 5-min intraday bars
    marketState: "UNKNOWN", // REGULAR | PRE | POST | CLOSED
    lastUpdated: null,
    nextRefresh: null,
    loading:     true,
    error:       null,
    isLive:      false,     // true = real data, false = fallback
  });

  const timerRef = useRef(null);
  const mountedRef = useRef(true);

  const fetchPrices = useCallback(async () => {
    setState(s => ({ ...s, loading: true, error: null }));
    try {
      // Use relative URL — works both locally (vite dev proxy) and on Vercel
      const res = await fetch("/api/prices", { cache: "no-store" });

      if (!res.ok) throw new Error(`API ${res.status}`);
      const data = await res.json();

      if (!mountedRef.current) return;

      if (data.fallback || !data.gold) {
        // API responded but no data — keep last known + mark as stale
        setState(s => ({ ...s, loading:false, error:"Market data unavailable", isLive:false }));
        return;
      }

      // Also fetch intraday bars for the chart
      let bars = [];
      try {
        const chartRes = await fetch("/api/chart?interval=5m&range=1d", { cache:"no-store" });
        if (chartRes.ok) {
          const chartData = await chartRes.json();
          bars = chartData.bars || [];
        }
      } catch(e) { /* bars stay empty */ }

      setState({
        gold:          data.gold.price,
        goldChange:    data.gold.change,
        goldChangePct: data.gold.changePct,
        goldDayHigh:   data.gold.dayHigh,
        goldDayLow:    data.gold.dayLow,
        dxy:           data.dxy?.price  || TODAY.dxy,
        dxyChange:     data.dxy?.change || 0,
        bars,
        marketState:   data.gold.marketState,
        lastUpdated:   data.fetchedAt,
        nextRefresh:   data.fetchedAt + REFRESH_MS,
        loading:       false,
        error:         null,
        isLive:        true,
      });

    } catch(err) {
      if (!mountedRef.current) return;
      setState(s => ({
        ...s,
        loading: false,
        error: err.message,
        isLive: false,
        // Keep last known prices
      }));
    }
  }, []);

  // Initial fetch + polling
  useEffect(() => {
    mountedRef.current = true;
    fetchPrices();
    timerRef.current = setInterval(fetchPrices, REFRESH_MS);
    return () => {
      mountedRef.current = false;
      clearInterval(timerRef.current);
    };
  }, [fetchPrices]);

  // Countdown to next refresh
  const [countdown, setCountdown] = useState(REFRESH_MS / 1000);
  useEffect(() => {
    const tick = setInterval(() => {
      if (state.nextRefresh) {
        const secs = Math.max(0, Math.round((state.nextRefresh - Date.now()) / 1000));
        setCountdown(secs);
      }
    }, 1000);
    return () => clearInterval(tick);
  }, [state.nextRefresh]);

  return { ...state, countdown, refresh: fetchPrices };
}
