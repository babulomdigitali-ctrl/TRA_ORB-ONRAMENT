export const C = {
  bg:     "#05050B",
  card:   "#0A0A16",
  deep:   "#030307",
  border: "#181828",
  borderGold: "#3A2A08",
  gold:   "#C8941F",
  goldL:  "#E6B440",
  goldD:  "#5A3E10",
  text:   "#D5CDB8",
  muted:  "#504840",
  dim:    "#201E18",
  bull:   "#35A860",
  bear:   "#C04040",
  neutral:"#C88010",
  moon:   "#9888C0",
  gann:   "#3A7EC0",
  dxy:    "#6858CC",
  accent: "#8B3A1A",
};

export const font = "Georgia, 'Times New Roman', serif";
export const mono = "'Courier New', monospace";
